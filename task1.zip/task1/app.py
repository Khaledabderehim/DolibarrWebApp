from flask import Flask, jsonify, json, render_template, request, redirect, url_for, session, flash, send_file
import requests
from io import BytesIO
import os
from dotenv import load_dotenv
from datetime import datetime
from functools import wraps
from flask import request, redirect, url_for
import json
from datetime import datetime
import sqlite3

ACTIVITY_FILE = 'user_activity.json'

def load_or_create_activity_file(file_path=ACTIVITY_FILE):
    if not os.path.exists(file_path):
        # Create a new file with default values
        with open(file_path, 'w') as f:
            json.dump([], f)  # Start with an empty list

    try:
        with open(file_path, 'r') as f:
            activities = json.load(f)
            if not isinstance(activities, list):  # Ensure it is a list
                activities = []
    except json.JSONDecodeError:
        print("JSONDecodeError: The file is empty or contains invalid JSON. Creating a new file.")
        activities = []  # Start fresh if there's an error
        with open(file_path, 'w') as f:
            json.dump(activities, f)  # Write a valid empty list back to the file

    return activities



# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('secret_key') # Remplacez par une clé secrète sécurisée

DATABASE_API_URL = os.getenv('DATABASE_API_URL')
FTP_API_URL = os.getenv('FTP_API_URL')


@app.route('/forgetpass', methods=['GET', 'POST'])
def forgetpass():
    return render_template('forgetpass.html')


def count_view(lastname):
    # Connect to the SQLite database
    conn = sqlite3.connect('activities.db')
    cursor = conn.cursor()

    # Query the activities table for total_viewed where the user_id matches the provided lastname
    cursor.execute('SELECT total_viewed FROM activities WHERE user_id = ? ORDER BY id DESC LIMIT 1', (lastname,))
    result = cursor.fetchone()

    # Close the database connection
    conn.close()

    # Check if a result was returned
    if result:
        total_viewed = result[0]  # Get total_viewed from the first match
        print(f"Total viewed for user '{lastname}':", total_viewed)
        return total_viewed
    else:
        print("No activities found for the user.")
        return None



@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        response = requests.post(f'{DATABASE_API_URL}/authenticate', json={'username': username, 'password': password})

        if response.status_code == 200:
            session['user_id'] = response.json()['user_id']
            session['username'] = username

            # Session info of name and civility
            session['name'] = response.json().get('name')
            session['civility'] = response.json().get('civility')

            # Use the correct field for the last name
            lastname = session['username']  # Adjust if necessary
            
            # Send lastname as a query parameter
            notification_response = requests.get(f'{DATABASE_API_URL}/notification_number', params={'lastname': lastname})

            # Log the status code and response for debugging
            print(f'Notification API response status code: {notification_response.status_code}')
            if notification_response.status_code == 200:
                documents_count = notification_response.json().get('filenames', 0)  # Access the correct field
                
                num = count_view(lastname)  # Call your count_json function
                
                # If num is None, set it to 0 to avoid TypeError
                if num is None:
                    num = 0
                
                # Store the new document count in session
                session['new_documents_count'] = documents_count - num

                return redirect(url_for('base'))
            else:
                # Print the error message from the notification response for debugging
                error_message = notification_response.json().get('error', 'Unknown error')
                print(f'Error retrieving document count: {error_message}')
                flash('Could not retrieve document count')

        else:
            # Show message for login failure
            flash('Email ou mot de passe invalide')

    return render_template('login.html')




#new route dashboard with dynamic name and civility
@app.route('/base')
def base():
    if 'username' not in session:
        return redirect(url_for('login'))
    #api call to echeance total to get the sum of echeance and provide it in dashboard
    username = session.get('username')
    response = requests.get(f'{DATABASE_API_URL}/echeance_total', params={'lastname': username})
    if response.status_code == 200:
        return render_template('/base.html')
    else:
        return redirect(url_for('login'))



# 
"""@app.route('/documents')
def documents():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session.get('username')
    response = requests.get(f'{DATABASE_API_URL}/documents', params={'lastname': username})
    if response.status_code == 200:
        documents = response.json()
        for document in documents:
            document['download_url'] = url_for('download_document', filepath=document['filepath'], filename=document['filename'])
        return render_template('documents.html', documents=documents)
    else:
        flash('Failed to fetch documents')
        return redirect(url_for('login'))
"""


@app.route('/download/<path:filepath>/<filename>')
def download_document(filepath, filename):
    response = requests.get(f'{FTP_API_URL}/download', params={'filepath': filepath, 'filename': filename})
    if response.status_code == 200:
        return send_file(BytesIO(response.content), as_attachment=True, download_name=filename)
    else:
        flash('Failed to download document')
        return redirect(url_for('courrier'))
    
@app.route('/view/<path:filepath>/<filename>')
def view_document(filepath, filename):
    # Make a request to the FTP API to get the file content
    response = requests.get(f'{FTP_API_URL}/download', params={'filepath': filepath, 'filename': filename})
    if response.status_code == 200:
        # Retrieve username from session
        username = session.get('username')

        # Connect to the SQLite database
        conn = sqlite3.connect('activities.db')
        cursor = conn.cursor()

        # Check if the activity already exists
        cursor.execute('SELECT * FROM activities WHERE user_id = ? AND document_id = ?', (username, filename))
        activity = cursor.fetchone()

        if not activity:
            # Track the activity if it's not a duplicate
            timestamp = datetime.now().isoformat()
            cursor.execute('INSERT INTO activities (user_id, document_id, action, timestamp) VALUES (?, ?, ?, ?)',
                           (username, filename, 'viewed', timestamp))

            # Calculate total viewed for the user
            cursor.execute('SELECT COUNT(*) FROM activities WHERE user_id = ?', (username,))
            total_viewed = cursor.fetchone()[0]

            # Update total_viewed for all activities of the user
            cursor.execute('UPDATE activities SET total_viewed = ? WHERE user_id = ?', (total_viewed, username))

            conn.commit()

        conn.close()

        # Send the file as inline (display in browser)
        return send_file(BytesIO(response.content), as_attachment=False, download_name=filename)
    else:
        flash('Failed to load document')
        return redirect(url_for('courrier'))

#new route dashboard with dynamic name and civility
@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    name = session.get('name', 'Guest')
    civility = session.get('civility', 'Mr/Mrs')
    #api call to echeance total to get the sum of echeance and provide it in dashboard
    username = session.get('username')
    number = session.get('new_documents_count')

    response = requests.get(f'{DATABASE_API_URL}/echeance_total', params={'lastname': username})
    if response.status_code == 200:
        return render_template('/partials/dashboard.html/',  number=number, name=name, civility=civility, total=response.json(), )
    else:
        return redirect(url_for('login'))


#new route to courrier with dynamic table of courrier
@app.route('/courrier')
def courrier():
    if 'username' not in session:   
        return redirect(url_for('login'))
    username = session.get('username')
    response = requests.get(f'{DATABASE_API_URL}/documents', params={'lastname': username})
    if response.status_code == 200:
        documents = response.json()
        for document in documents:
            document['download_url'] = url_for('download_document', filepath=document['filepath'], filename=document['filename'])
        return render_template('/partials/courrier.html', documents=documents)
    else:
        flash('Failed to fetch documents')
        return redirect(url_for('login'))
    
#new route to echeance
@app.route('/echeance')
def echeance():
    if request.path != '/base':
        return redirect(url_for('login'))
    if 'username' not in session:   
        return redirect(url_for('login'))
    #recuperation du username du session
    username = session.get('username')
    #api call au base de donne /echance
    response = requests.get(f'{DATABASE_API_URL}/echeance', params={'lastname': username})
    if response.status_code == 200:
        echeances = response.json()
        return render_template('/partials/echeance.html', echeances = echeances)
    else:
        return redirect(url_for('login'))
    

@app.route('/logout')
def logout():
    # Logic to clear the user session or perform logout
    session.clear()  # Example of clearing the session
    return redirect(url_for('login'))  # Redirect to the login page or home page

def activity_exists(activities, username, filename):
    return any(activity for activity in activities if activity['user_id'] == username and activity['document_id'] == filename)



@app.route('/document_details')
def document_details():
    filename = request.args.get('filename')
    username = session.get('username')
    
    conn = sqlite3.connect('activities.db')
    cursor = conn.cursor()

    # Check if the activity already exists
    cursor.execute('SELECT * FROM activities WHERE user_id = ? AND document_id = ?', (username, filename))
    activity = cursor.fetchone()

    if not activity:
        # Track the activity if it's not a duplicate
        timestamp = datetime.now().isoformat()
        cursor.execute('INSERT INTO activities (user_id, document_id, action, timestamp) VALUES (?, ?, ?, ?)',
                       (username, filename, 'viewed', timestamp))

        # Calculate total viewed for the user
        cursor.execute('SELECT COUNT(*) FROM activities WHERE user_id = ?', (username,))
        total_viewed = cursor.fetchone()[0]

        # Update total_viewed for all activities of the user
        cursor.execute('UPDATE activities SET total_viewed = ? WHERE user_id = ?', (total_viewed, username))

        conn.commit()

    conn.close()

    # Redirect to base after updating
    return redirect(request.referrer)







if __name__ == '__main__':
    app.run(debug=True)