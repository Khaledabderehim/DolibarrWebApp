from flask import Flask, request, jsonify
import mysql.connector
import bcrypt
import os

#import de dotenv : to hold enviroment variables 
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


app = Flask(__name__)


def connect_to_database():
    try:
        connection = mysql.connector.connect(
            # using variables directly from the env
            host=os.getenv('host'),
            user=os.getenv('user'),
            password=os.getenv('password'),
            database=os.getenv('database')
        )
        return connection
    except mysql.connector.Error as err:
        print(f"Erreur lors de la connexion à la base de données: {err}")
        return None

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "ok"}), 200

@app.route('/authenticate', methods=['POST'])
def authenticate_user():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    connection = connect_to_database()
    if connection is None:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = connection.cursor(dictionary=True)

        #cursor.execute("SELECT rowid, pass_crypted FROM llx_user WHERE login = %s", (username,))
        
        cursor.execute("SELECT rowid, pass_crypted, civility, lastname, address FROM llx_user WHERE login = %s", (username,))
        user = cursor.fetchone()
    finally:
        connection.close()

    if user:
        #getting the civility and name from the base
        civility, name = user['civility'], user['lastname']

        rowid, pass_crypted = user['rowid'], user['pass_crypted']
        if bcrypt.checkpw(password.encode('utf-8'), pass_crypted.encode('utf-8')):
            #return jsonify({"user_id": rowid}), 200
            return jsonify({"user_id": rowid, "civility":civility, "name":name }), 200

    return jsonify({"error": "Authentication failed"}), 401





@app.route('/documents', methods=['GET'])
def fetch_documents_by_lastname():
    lastname = request.args.get('lastname')

    connection = connect_to_database()
    if connection is None:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        sql = """
            SELECT ecm.filename, ecm.filepath, ecm.fullpath_orig, ecm.description, ecm.date_c, ecm.fk_user_c
            FROM llx_ecm_files AS ecm
            JOIN llx_socpeople AS sp ON sp.rowid = ecm.src_object_id
            WHERE ecm.src_object_type = 'socpeople' AND sp.lastname = %s
        """
        cursor.execute(sql, (lastname,))
        documents = cursor.fetchall()
    finally:
        connection.close()

    return jsonify(documents), 200

#echeance route to get all facture and their status 
@app.route('/echeance', methods=['GET'])
def fetch_echeance_by_lastname():
    lastname = request.args.get('lastname')
    connection = connect_to_database()
    if connection is None:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        sql = """
            SELECT
                f.rowid AS facture_id,
                f.ref AS invoice_reference,
                f.total_ttc AS invoice_total,
                f.fk_statut AS invoice_status,
                p.lastname AS lastname -- Contact last name (from llx_socpeople)
            FROM
                llx_facture AS f
            LEFT JOIN
                llx_societe AS s ON f.fk_soc = s.rowid
            LEFT JOIN
                llx_socpeople AS p ON f.fk_soc = p.fk_soc
            WHERE
                p.lastname = %s;
        """
        cursor.execute(sql, (lastname,))
        echeances = cursor.fetchall()
    finally:
        connection.close()

    return jsonify(echeances), 200

#echeance total pour l'afficher dans la page d'acceuil
@app.route('/echeance_total', methods=['GET'])
def fetch_echeance_total():
    lastname = request.args.get('lastname')
    connection = connect_to_database()
    if connection is None:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        sql = """
            SELECT
                SUM(f.total_ttc) AS total_unpaid_amount
            FROM
                llx_facture AS f
            LEFT JOIN
                llx_societe AS s ON f.fk_soc = s.rowid
            LEFT JOIN
                llx_socpeople AS p ON f.fk_soc = p.fk_soc
            WHERE
                p.lastname = %s AND f.fk_statut = 1;
        """
        cursor.execute(sql, (lastname,))
        result = cursor.fetchone()  # Fetch the result which contains the total sum

        # Extract the total amount from the result
        total_unpaid_amount = result['total_unpaid_amount'] if result['total_unpaid_amount'] is not None else 0
    finally:
        connection.close()

    return jsonify({"total_unpaid_amount": total_unpaid_amount}), 200


@app.route('/document_details', methods=['GET'])
def document_details():
    lastname = request.args.get('lastname')
    filename = request.args.get('filename')

    connection = connect_to_database()
    if connection is None:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        sql = """
            SELECT ecm.filename, ecm.filepath, ecm.fullpath_orig, ecm.description, ecm.date_c, ecm.fk_user_c
            FROM llx_ecm_files AS ecm
            JOIN llx_socpeople AS sp ON sp.rowid = ecm.src_object_id
            WHERE ecm.src_object_type = 'socpeople' AND sp.lastname = %s AND ecm.filename = %s
        """
        cursor.execute(sql, (lastname, filename))
        document = cursor.fetchone()
    finally:
        connection.close()

    return jsonify(document), 200


@app.route('/notification_number', methods=['GET'])
def notification_number():
    lastname = request.args.get('lastname')
    
    # Print the received lastname parameter for debugging
    print("Received lastname parameter:", lastname)

    # Validate the last name parameter
    if not lastname:
        return jsonify({"error": "Last name parameter is required"}), 400

    connection = connect_to_database()
    if connection is None:
        return jsonify({"error": "Database connection failed"}), 500

    try:
        cursor = connection.cursor(dictionary=True)
        sql = """
            SELECT ecm.filename as filename
            FROM llx_ecm_files AS ecm
            JOIN llx_socpeople AS sp ON sp.rowid = ecm.src_object_id
            WHERE ecm.src_object_type = 'socpeople' AND sp.lastname = %s
        """
        cursor.execute(sql, (lastname,))
        results = cursor.fetchall()  # Fetch all matching records

        # Check if results is empty
        if not results:
            return jsonify({"message": "No documents found"}), 404

        # Extract filenames from the results
        file_count = len(results)

        # Print the filenames to the console
        print("Filenames found:", file_count)

    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        connection.close()

    return jsonify({"filenames": file_count}), 200






if __name__ == '__main__':
    app.run(port=5001, debug=True)