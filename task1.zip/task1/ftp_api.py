from flask import Flask, request, send_file, jsonify
from ftplib import FTP
from io import BytesIO
import os

app = Flask(__name__)

@app.route('/download', methods=['GET'])
def download_document():
    filepath = request.args.get('filepath')
    filename = request.args.get('filename')

    ftp_host = 'ftp.dagpro.dev'
    ftp_user = 'u303329230.Dolibarr'
    ftp_pass = 'Tari@2009'

    ftp = FTP(ftp_host)
    ftp.login(user=ftp_user, passwd=ftp_pass)

    full_path = os.path.join('/documents', filepath, filename)
    full_path = full_path.replace('\\', '/')
    print(f"Attempting to retrieve file from FTP: {full_path}")

    bio = BytesIO()
    try:
        ftp.retrbinary(f'RETR {full_path}', bio.write)
    except Exception as e:
        print(f"Error retrieving file: {e}")
        return jsonify({"error": f"Error retrieving file: {e}"}), 500

    bio.seek(0)
    ftp.quit()

    return send_file(bio, as_attachment=True, download_name=filename)
@app.route('/view', methods=['GET'])
def view_document():
    filepath = request.args.get('filepath')
    filename = request.args.get('filename')

    ftp_host = 'ftp.dagpro.dev'
    ftp_user = 'u303329230.Dolibarr'
    ftp_pass = 'Tari@2009'

    ftp = FTP(ftp_host)
    ftp.login(user=ftp_user, passwd=ftp_pass)

    full_path = os.path.join('/documents', filepath, filename)
    full_path = full_path.replace('\\', '/')
    print(f"Attempting to retrieve file from FTP: {full_path}")

    bio = BytesIO()
    try:
        ftp.retrbinary(f'RETR {full_path}', bio.write)
    except Exception as e:
        print(f"Error retrieving file: {e}")
        return jsonify({"error": f"Error retrieving file: {e}"}), 500

    bio.seek(0)
    ftp.quit()

    # Display the file inline, which allows for viewing in the browser
    return send_file(bio, as_attachment=False, download_name=filename)

if __name__ == '__main__':
    app.run(port=5002, debug=True)