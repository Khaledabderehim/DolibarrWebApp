import sqlite3

def init_db():
    conn = sqlite3.connect('activities.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS activities (
                         id INTEGER PRIMARY KEY AUTOINCREMENT,
                         user_id TEXT NOT NULL,
                         document_id TEXT NOT NULL,
                         action TEXT NOT NULL,
                         timestamp TEXT NOT NULL,
                         total_viewed INTEGER
                     )''')
    conn.commit()
    conn.close()

init_db()  # Run this once to initialize the database
