    // script.js
    let currentPage = 'dashboard'; // Track the current page

    function changeContent(page) {
        event.preventDefault(); // Prevent default link behavior

        // Check if the requested page is the same as the current page
        if (currentPage === page) {
            return; // Do nothing if we're already on that page
        }

        let url = '';

        // Determine the correct route based on the page
        switch (page) {
            case 'dashboard':
                url = '/dashboard'; // Flask route for dashboard content
                break;
            case 'courrier':
                url = '/courrier'; // Adjust this to your courriers route
                break;
            case 'echeance':
                // Block content change for Échéances
                alert("Échéances cannot be accessed at this time.");
                return;
            default:
                url = '/dashboard'; // Fallback to dashboard
        }

        // Fetch the content from the Flask route
        fetch(url)
            .then(response => response.text())
            .then(data => {
                // Replace the #main-content with the new content
                document.getElementById('main-content').innerHTML = data;

                // Update the current page
                currentPage = page;
            })
            .catch(error => console.error('Error fetching content:', error));
    }
